<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'type' => 'text',
    'id',
    'name',
    'required' => false,
    'readonly' => false,
    'isNumber' => false,
    'value' => null,
    'helperText' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'type' => 'text',
    'id',
    'name',
    'required' => false,
    'readonly' => false,
    'isNumber' => false,
    'value' => null,
    'helperText' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php $__env->startPush('scripts'); ?>
    <?php if($isNumber): ?>
        <script src="<?php echo e(asset('assets/libs/autonumeric/autoNumeric.min.js')); ?>"></script>
        <script>
            new AutoNumeric('#<?php echo e($id); ?>', {
                allowDecimalPadding: false,
                modifyValueOnWheel: false
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<div class="mb-3">
    <label for="<?php echo e($id); ?>"
        class="inline-block mb-2 text-sm font-medium text-gray-800"><?php echo e($label); ?></label>
    <input type="<?php echo e($type); ?>" id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" class="form-input"
        value="<?php echo e($value); ?>" <?php echo e($readonly ? 'readonly' : ''); ?> <?php echo e($required ? 'required' : ''); ?>>
    <?php if($helperText): ?>
        <small class="italic text-gray-500"><?php echo e($helperText); ?></small>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\lbs\resources\views/components/form/input.blade.php ENDPATH**/ ?>