<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Event '.e(ucfirst(request()->route('status'))).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Event '.e(ucfirst(request()->route('status'))).'']); ?>
    <?php if (isset($component)) { $__componentOriginal8057c34406d2bfd6c33945ad36163ce7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8057c34406d2bfd6c33945ad36163ce7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal60afcd9de3ae73d82743a34dad7a3f27 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.datatable','data' => ['id' => 'table']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'table']); ?>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Event</th>
                    <th>Lokasi</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Selesai</th>
                    <th>Harga Tiket</th>
                    <th>Lokasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($event->nama); ?></td>
                        <td><?php echo e($event->lokasi); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($event->tanggal_mulai)->isoFormat('DD MMMM YYYY')); ?></td>
                        <td><?php echo e(Carbon\Carbon::parse($event->tanggal_selesai)->isoFormat('DD MMMM YYYY')); ?></td>
                        <td><?php echo e($event->harga_tiket ? 'Rp. ' . number_format($event->harga_tiket) : 'Gratis'); ?></td>
                        <?php if(request()->route('status') == 'aktif'): ?>
                            <td class="text-center">
                                <?php if (isset($component)) { $__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button','data' => ['label' => 'Edit','href' => ''.e(route('event.edit', ['status' => $event->status, 'event' => $event->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Edit','href' => ''.e(route('event.edit', ['status' => $event->status, 'event' => $event->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce)): ?>
<?php $attributes = $__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce; ?>
<?php unset($__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce)): ?>
<?php $component = $__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce; ?>
<?php unset($__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce); ?>
<?php endif; ?>
                                <form
                                    action="<?php echo e(route('event.destroy', ['status' => $event->status, 'event' => $event->id])); ?>"
                                    class="inline" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button-soft','data' => ['type' => 'submit','label' => 'Hapus','color' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button-soft'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','label' => 'Hapus','color' => 'danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9)): ?>
<?php $attributes = $__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9; ?>
<?php unset($__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9)): ?>
<?php $component = $__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9; ?>
<?php unset($__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9); ?>
<?php endif; ?>
                                </form>
                            </td>
                        <?php else: ?>
                            <td>
                                <?php if (isset($component)) { $__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button-soft','data' => ['label' => 'Lihat','color' => 'success','href' => ''.e(route('event.show-location', $event->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button-soft'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Lihat','color' => 'success','href' => ''.e(route('event.show-location', $event->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9)): ?>
<?php $attributes = $__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9; ?>
<?php unset($__attributesOriginala4a5d3cfbb1b73d88e72a336ca297ee9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9)): ?>
<?php $component = $__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9; ?>
<?php unset($__componentOriginala4a5d3cfbb1b73d88e72a336ca297ee9); ?>
<?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27)): ?>
<?php $attributes = $__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27; ?>
<?php unset($__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60afcd9de3ae73d82743a34dad7a3f27)): ?>
<?php $component = $__componentOriginal60afcd9de3ae73d82743a34dad7a3f27; ?>
<?php unset($__componentOriginal60afcd9de3ae73d82743a34dad7a3f27); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8057c34406d2bfd6c33945ad36163ce7)): ?>
<?php $attributes = $__attributesOriginal8057c34406d2bfd6c33945ad36163ce7; ?>
<?php unset($__attributesOriginal8057c34406d2bfd6c33945ad36163ce7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8057c34406d2bfd6c33945ad36163ce7)): ?>
<?php $component = $__componentOriginal8057c34406d2bfd6c33945ad36163ce7; ?>
<?php unset($__componentOriginal8057c34406d2bfd6c33945ad36163ce7); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\lbs\resources\views/pages/event.blade.php ENDPATH**/ ?>