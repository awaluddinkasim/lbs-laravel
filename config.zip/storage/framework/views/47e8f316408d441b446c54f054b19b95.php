<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/leaflet/leaflet.css')); ?>">
    <style>
        #map {
            height: 500px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/libs/leaflet/leaflet.js')); ?>"></script>
    <script>
        var map = L.map('map').setView([<?php echo e($event->latitude); ?>, <?php echo e($event->longitude); ?>], 14);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var marker = L.marker([<?php echo e($event->latitude); ?>, <?php echo e($event->longitude); ?>]).addTo(map);
    </script>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Peta Event']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Peta Event']); ?>
    <?php if (isset($component)) { $__componentOriginal8057c34406d2bfd6c33945ad36163ce7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8057c34406d2bfd6c33945ad36163ce7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div id="map"></div>
        <h2 class="mt-6 text-xl font-bold">Dekskripsi</h2>
        <p>
            <?php echo e($event->deskripsi); ?>

        </p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8057c34406d2bfd6c33945ad36163ce7)): ?>
<?php $attributes = $__attributesOriginal8057c34406d2bfd6c33945ad36163ce7; ?>
<?php unset($__attributesOriginal8057c34406d2bfd6c33945ad36163ce7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8057c34406d2bfd6c33945ad36163ce7)): ?>
<?php $component = $__componentOriginal8057c34406d2bfd6c33945ad36163ce7; ?>
<?php unset($__componentOriginal8057c34406d2bfd6c33945ad36163ce7); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\lbs\resources\views/pages/event/map.blade.php ENDPATH**/ ?>