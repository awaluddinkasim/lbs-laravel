<div class="card p-4 md:p-5">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\lbs\resources\views/components/component/card.blade.php ENDPATH**/ ?>