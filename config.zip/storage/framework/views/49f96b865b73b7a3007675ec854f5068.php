<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'type' => 'button', 'color' => 'primary', 'block' => false, 'href' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'type' => 'button', 'color' => 'primary', 'block' => false, 'href' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<button type="<?php echo e($type); ?>"
    class="btn bg-<?php echo e($color); ?>/25 text-<?php echo e($color); ?> hover:bg-<?php echo e($color); ?> hover:text-white <?php echo e($block ? 'w-full' : ''); ?>"
    <?php echo $href ? 'onclick="document.location.href = \'' . $href . '\'"' : ''; ?>>
    <?php echo e($label); ?>

</button>
<?php /**PATH C:\laragon\www\lbs\resources\views/components/component/button-soft.blade.php ENDPATH**/ ?>