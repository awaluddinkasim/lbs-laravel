<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'id', 'name', 'rows' => 2, 'required' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'id', 'name', 'rows' => 2, 'required' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mb-3">
    <label for="<?php echo e($id); ?>"
        class="text-gray-800 text-sm font-medium inline-block mb-2"><?php echo e($label); ?></label>
    <textarea id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" class="form-input" <?php echo e($required ? 'required' : ''); ?>

        rows="<?php echo e($rows); ?>"><?php echo e($slot); ?></textarea>
</div>
<?php /**PATH C:\laragon\www\lbs\resources\views/components/form/textarea.blade.php ENDPATH**/ ?>