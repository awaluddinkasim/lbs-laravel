<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login | <?php echo e(config('app.name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body>
    <div class="flex min-h-screen justify-center items-center bg-slate-100">
        <div class="bg-white rounded-xl p-5 pb-8 w-96 max-w-full">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="w-1/2 mx-auto my-4">

            <?php if(Session::has('error')): ?>
                <div class="text-center text-red-500 bg-red-100 rounded mb-3 py-2"><?php echo e(Session::get('error')); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('authenticate')); ?>" method="post" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="email" class="block text-sm font-medium leading-6 text-gray-900">Email</label>
                    <input type="text" name="email" id="emailInput"
                        class="block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                        value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="block text-sm font-medium leading-6 text-gray-900">Password</label>
                    <input type="password" name="password" id="passwordInput"
                        class="block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                        required>
                </div>
                <button class="py-1 w-full mt-4 bg-indigo-400 text-white rounded">Login</button>
            </form>

            <div class="text-center mt-4">
                <span>Copyright &copy; 2024 <?php echo e(config('app.name')); ?></span>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/libs/sweetalert2/sweetalert2.all.min.js')); ?>"></script>

    <?php if(Session::has('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?php echo e(Session::get('success')); ?>',
            })
        </script>
    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\laragon\www\lbs\resources\views/auth.blade.php ENDPATH**/ ?>