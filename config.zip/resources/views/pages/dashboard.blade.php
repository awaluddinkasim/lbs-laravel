<x-layout>
    <h1>Cobaa</h1>
</x-layout>
