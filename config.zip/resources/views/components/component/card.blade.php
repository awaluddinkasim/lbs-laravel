<div class="card p-4 md:p-5">
    {{ $slot }}
</div>
